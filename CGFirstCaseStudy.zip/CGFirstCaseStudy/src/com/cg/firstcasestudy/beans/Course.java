package com.cg.firstcasestudy.beans;
import java.util.HashMap;
public class Course {
	private int courseId,duration,courseFee,startingDate,endingDate;
	private String typeOfcourse,nameOfCourse;
	private HashMap<Integer, Subject> subjects=new HashMap<Integer, Subject>();
	public Course() {
		super();
	}
	public Course(int courseId, int duration, int courseFee, int startingDate,
			int endingDate, String typeOfcourse, String nameOfCourse,
			HashMap<Integer, Subject> subjects) {
		super();
		this.courseId = courseId;
		this.duration = duration;
		this.courseFee = courseFee;
		this.startingDate = startingDate;
		this.endingDate = endingDate;
		this.typeOfcourse = typeOfcourse;
		this.nameOfCourse = nameOfCourse;
		this.subjects = subjects;
	}
	public int getCourseId() {
		return courseId;
	}
	public void setCourseId(int courseId) {
		this.courseId = courseId;
	}
	public int getDuration() {
		return duration;
	}
	public void setDuration(int duration) {
		this.duration = duration;
	}
	public int getCourseFee() {
		return courseFee;
	}
	public void setCourseFee(int courseFee) {
		this.courseFee = courseFee;
	}
	public int getStartingDate() {
		return startingDate;
	}
	public void setStartingDate(int startingDate) {
		this.startingDate = startingDate;
	}
	public int getEndingDate() {
		return endingDate;
	}
	public void setEndingDate(int endingDate) {
		this.endingDate = endingDate;
	}
	public String getTypeOfcourse() {
		return typeOfcourse;
	}
	public void setTypeOfcourse(String typeOfcourse) {
		this.typeOfcourse = typeOfcourse;
	}
	public String getNameOfCourse() {
		return nameOfCourse;
	}
	public void setNameOfCourse(String nameOfCourse) {
		this.nameOfCourse = nameOfCourse;
	}
	public HashMap<Integer, Subject> getSubjects() {
		return subjects;
	}
	public void setSubjects(HashMap<Integer, Subject> subjects) {
		this.subjects = subjects;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + courseFee;
		result = prime * result + courseId;
		result = prime * result + duration;
		result = prime * result + endingDate;
		result = prime * result
				+ ((nameOfCourse == null) ? 0 : nameOfCourse.hashCode());
		result = prime * result + startingDate;
		result = prime * result
				+ ((subjects == null) ? 0 : subjects.hashCode());
		result = prime * result
				+ ((typeOfcourse == null) ? 0 : typeOfcourse.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Course other = (Course) obj;
		if (courseFee != other.courseFee)
			return false;
		if (courseId != other.courseId)
			return false;
		if (duration != other.duration)
			return false;
		if (endingDate != other.endingDate)
			return false;
		if (nameOfCourse == null) {
			if (other.nameOfCourse != null)
				return false;
		} else if (!nameOfCourse.equals(other.nameOfCourse))
			return false;
		if (startingDate != other.startingDate)
			return false;
		if (subjects == null) {
			if (other.subjects != null)
				return false;
		} else if (!subjects.equals(other.subjects))
			return false;
		if (typeOfcourse == null) {
			if (other.typeOfcourse != null)
				return false;
		} else if (!typeOfcourse.equals(other.typeOfcourse))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "Course [courseId=" + courseId + ", duration=" + duration
				+ ", courseFee=" + courseFee + ", startingDate=" + startingDate
				+ ", endingDate=" + endingDate + ", typeOfcourse="
				+ typeOfcourse + ", nameOfCourse=" + nameOfCourse
				+ ", subjects=" + subjects + "]";
	}
}
