package com.cg.firstcasestudy.beans;
public class Discount {
	private int discountAvailability,discountDateDeadline;
	private String discountCode;
	public Discount() {
		super();
	}
	public Discount(int discountAvailability, int discountDateDeadline,
			String discountCode) {
		super();
		this.discountAvailability = discountAvailability;
		this.discountDateDeadline = discountDateDeadline;
		this.discountCode = discountCode;
	}
	public int getDiscountAvailability() {
		return discountAvailability;
	}
	public void setDiscountAvailability(int discountAvailability) {
		this.discountAvailability = discountAvailability;
	}
	public int getDiscountDateDeadline() {
		return discountDateDeadline;
	}
	public void setDiscountDateDeadline(int discountDateDeadline) {
		this.discountDateDeadline = discountDateDeadline;
	}
	public String getDiscountCode() {
		return discountCode;
	}
	public void setDiscountCode(String discountCode) {
		this.discountCode = discountCode;
	}
	@Override
	public String toString() {
		return "Discount [discountAvailability=" + discountAvailability
				+ ", discountDateDeadline=" + discountDateDeadline
				+ ", discountCode=" + discountCode + "]";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + discountAvailability;
		result = prime * result
				+ ((discountCode == null) ? 0 : discountCode.hashCode());
		result = prime * result + discountDateDeadline;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Discount other = (Discount) obj;
		if (discountAvailability != other.discountAvailability)
			return false;
		if (discountCode == null) {
			if (other.discountCode != null)
				return false;
		} else if (!discountCode.equals(other.discountCode))
			return false;
		if (discountDateDeadline != other.discountDateDeadline)
			return false;
		return true;
	}
}
