package com.cg.firstcasestudy.beans;
public class Payment {
	private String paymentStatus;
	private int paymentDate,paymentAmount;
	public Payment() {
		super();
	}
	public Payment(String paymentStatus, int paymentDate, int paymentAmount) {
		super();
		this.paymentStatus = paymentStatus;
		this.paymentDate = paymentDate;
		this.paymentAmount = paymentAmount;
	}
	public String getPaymentStatus() {
		return paymentStatus;
	}
	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}
	public int getPaymentDate() {
		return paymentDate;
	}
	public void setPaymentDate(int paymentDate) {
		this.paymentDate = paymentDate;
	}
	public int getPaymentAmount() {
		return paymentAmount;
	}
	public void setPaymentAmount(int paymentAmount) {
		this.paymentAmount = paymentAmount;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + paymentAmount;
		result = prime * result + paymentDate;
		result = prime * result
				+ ((paymentStatus == null) ? 0 : paymentStatus.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Payment other = (Payment) obj;
		if (paymentAmount != other.paymentAmount)
			return false;
		if (paymentDate != other.paymentDate)
			return false;
		if (paymentStatus == null) {
			if (other.paymentStatus != null)
				return false;
		} else if (!paymentStatus.equals(other.paymentStatus))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "Payment [paymentStatus=" + paymentStatus + ", paymentDate="
				+ paymentDate + ", paymentAmount=" + paymentAmount + "]";
	}
}
