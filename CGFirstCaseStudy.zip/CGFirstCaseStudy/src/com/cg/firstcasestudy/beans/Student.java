package com.cg.firstcasestudy.beans;
import java.util.HashMap;
public class Student {
	private int	studentId,mobileno,adharNo;
	private String firstName,lastName,emailId;
	private HashMap<Integer, Course> students=new HashMap<Integer, Course>();
	public Student() {
		super();
	}
	public Student(int studentId, int mobileno, int adharNo, String firstName,
			String lastName, String emailId, HashMap<Integer, Course> students) {
		super();
		this.studentId = studentId;
		this.mobileno = mobileno;
		this.adharNo = adharNo;
		this.firstName = firstName;
		this.lastName = lastName;
		this.emailId = emailId;
		this.students = students;
	}
public Student(int mobileno, int adharNo, String firstName,
			String lastName, String emailId, HashMap<Integer, Course> students) {
		super();
		this.mobileno = mobileno;
		this.adharNo = adharNo;
		this.firstName = firstName;
		this.lastName = lastName;
		this.emailId = emailId;
		this.students = students;
	}
public int getStudentId() {
		return studentId;
	}
	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}
	public int getMobileno() {
		return mobileno;
	}
	public void setMobileno(int mobileno) {
		this.mobileno = mobileno;
	}
	public int getAdharNo() {
		return adharNo;
	}
	public void setAdharNo(int adharNo) {
		this.adharNo = adharNo;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public HashMap<Integer, Course> getStudents() {
		return students;
	}
	public void setStudents(HashMap<Integer, Course> students) {
		this.students = students;
	}
	@Override
	public String toString() {
		return "Student [studentId=" + studentId + ", mobileno=" + mobileno
				+ ", adharNo=" + adharNo + ", firstName=" + firstName
				+ ", lastName=" + lastName + ", emailId=" + emailId + ", students="
				+ students + "]";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + adharNo;
		result = prime * result + ((emailId == null) ? 0 : emailId.hashCode());
		result = prime * result + ((firstName == null) ? 0 : firstName.hashCode());
		result = prime * result + ((lastName == null) ? 0 : lastName.hashCode());
		result = prime * result + mobileno;
		result = prime * result + studentId;
		result = prime * result + ((students == null) ? 0 : students.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Student other = (Student) obj;
		if (adharNo != other.adharNo)
			return false;
		if (emailId == null) {
			if (other.emailId != null)
				return false;
		} else if (!emailId.equals(other.emailId))
			return false;
		if (firstName == null) {
			if (other.firstName != null)
				return false;
		} else if (!firstName.equals(other.firstName))
			return false;
		if (lastName == null) {
			if (other.lastName != null)
				return false;
		} else if (!lastName.equals(other.lastName))
			return false;
		if (mobileno != other.mobileno)
			return false;
		if (studentId != other.studentId)
			return false;
		if (students == null) {
			if (other.students != null)
				return false;
		} else if (!students.equals(other.students))
			return false;
		return true;
	}
}
