package com.cg.firstcasestudy.daoservices;
import java.util.List;
import com.cg.firstcasestudy.beans.Course;
import com.cg.firstcasestudy.beans.Student;
import com.cg.firstcasestudy.beans.Subject;
public interface CaseDAOService {
int insertStudent(Student student);
int insertCourse(Course course);
int insertSubject(Subject subject);
int updateStudent(int studentID,Student student);
int updateCourse(int studentId, Course course);
boolean deleteStudent(int studentId );
boolean deleteCourse(int studentId,int courseId);
Student getStudent(int studentId);
Course getCourse(int studentID,int coureId);
List<Student> getStudents();
List<Course> getCourses(int studentId);
List<Subject> getSubjects(int studentId,int courseId);
}
