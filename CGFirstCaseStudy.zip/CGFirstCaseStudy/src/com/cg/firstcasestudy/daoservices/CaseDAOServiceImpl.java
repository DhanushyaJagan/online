package com.cg.firstcasestudy.daoservices;

import java.util.List;

import com.cg.firstcasestudy.beans.Course;
import com.cg.firstcasestudy.beans.Student;
import com.cg.firstcasestudy.beans.Subject;

public class CaseDAOServiceImpl implements CaseDAOService{
	@Override
	public int insertStudent(Student student) {
		return 0;
	}
	@Override
	public int insertCourse(Course course) {
		return 0;
	}
	@Override
	public int insertSubject(Subject subject) {
		return 0;
	}
	@Override
	public int updateStudent(int studentID, Student student) {
		return 0;
	}
	@Override
	public int updateCourse(int studentId, Course course) {
		return 0;
	}
	@Override
	public boolean deleteStudent(int studentId) {
		return false;
	}
	@Override
	public boolean deleteCourse(int studentId, int courseId) {
		return false;
	}
	@Override
	public Student getStudent(int studentId) {
		return null;
	}
	@Override
	public Course getCourse(int studentID, int coureId) {
		return null;
	}
	@Override
	public List<Student> getStudents() {
		return null;
	}
	@Override
	public List<Course> getCourses(int studentId) {
		return null;
	}
	@Override
	public List<Subject> getSubjects(int studentId, int courseId) {
		return null;
	}
}

