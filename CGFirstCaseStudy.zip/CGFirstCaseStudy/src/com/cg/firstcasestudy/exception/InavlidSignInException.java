package com.cg.firstcasestudy.exception;
public class InavlidSignInException extends Exception {
	public InavlidSignInException() {
		super();
	}
	public InavlidSignInException(String message, Throwable cause,
			boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}
	public InavlidSignInException(String message, Throwable cause) {
		super(message, cause);
	}
	public InavlidSignInException(String message) {
		super(message);
	}
	public InavlidSignInException(Throwable cause) {
		super(cause);
	}
}
