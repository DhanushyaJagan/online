package com.cg.firstcasestudy.exception;
public class InvalidCourseTypeException extends Exception {

	public InvalidCourseTypeException() {
		super();
	}
	public InvalidCourseTypeException(String message, Throwable cause,
			boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}
	public InvalidCourseTypeException(String message, Throwable cause) {
		super(message, cause);
	}
	public InvalidCourseTypeException(String message) {
		super(message);
	}
	public InvalidCourseTypeException(Throwable cause) {
		super(cause);
	}
}
