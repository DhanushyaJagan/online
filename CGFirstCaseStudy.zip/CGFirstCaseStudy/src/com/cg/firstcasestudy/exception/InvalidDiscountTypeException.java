package com.cg.firstcasestudy.exception;
public class InvalidDiscountTypeException extends Exception {

	public InvalidDiscountTypeException() {
		super();
	}
	public InvalidDiscountTypeException(String message, Throwable cause,
			boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}
	public InvalidDiscountTypeException(String message, Throwable cause) {
		super(message, cause);
	}
	public InvalidDiscountTypeException(String message) {
		super(message);
	}
	public InvalidDiscountTypeException(Throwable cause) {
		super(cause);
	}
}
