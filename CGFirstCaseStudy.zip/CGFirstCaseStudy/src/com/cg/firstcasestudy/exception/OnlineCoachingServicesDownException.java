package com.cg.firstcasestudy.exception;
 class OnlineCoachingServicesDownException extends Exception {
	public OnlineCoachingServicesDownException() {
		super();
	}
	public OnlineCoachingServicesDownException(String message, Throwable cause,
			boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}
	public OnlineCoachingServicesDownException(String message, Throwable cause) {
		super(message, cause);
	}
	public OnlineCoachingServicesDownException(String message) {
		super(message);
	}
	public OnlineCoachingServicesDownException(Throwable cause) {
		super(cause);
	}
}
