package com.cg.firstcasestudy.services;
import java.util.List;
import com.cg.firstcasestudy.beans.Course;
import com.cg.firstcasestudy.beans.Payment;
import com.cg.firstcasestudy.beans.Student;
import com.cg.firstcasestudy.beans.Subject;
public interface CaseService {
int acceptStudentDetails(int mobileno, int adharNo, String firstName,
		String lastName, String emailId,String city,
		String state, String country, int pincode);
int addCourse(int studentId, String nameOfCourse);
int addSubject(int studentId, int courseId, String subjectName);
int discountPercent(int studentId, int courseId, int subjectId);
float calculatePaymentAmount(int studentId);
Student getStudentDetails(int studentId);
Course getCourseDetails(int studentId,int courseId);
Subject getSubjectDetails(int studentId,int courseId,int subjectId);
List<Student> getAllStudentDetails();
List<Course> getAllCourseDetails();
List<Subject> getAllSubjecttDetails();
List<Payment> getAllPaymentDetails();
}
