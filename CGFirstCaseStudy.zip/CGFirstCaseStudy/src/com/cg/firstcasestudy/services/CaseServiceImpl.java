package com.cg.firstcasestudy.services;
import java.util.List;
import com.cg.firstcasestudy.beans.Course;
import com.cg.firstcasestudy.beans.Payment;
import com.cg.firstcasestudy.beans.Student;
import com.cg.firstcasestudy.beans.Subject;

public class CaseServiceImpl implements CaseService {

	@Override
	public int acceptStudentDetails(int mobileno, int adharNo,
			String firstName, String lastName, String emailId, String city,
			String state, String country, int pincode) {
		return 0;
	}

	@Override
	public int addCourse(int studentId, String nameOfCourse) {
		return 0;
	}

	@Override
	public int addSubject(int studentId, int courseId, String subjectName) {
		return 0;
	}

	@Override
	public int discountPercent(int studentId, int courseId, int subjectId) {
		return 0;
	}

	@Override
	public float calculatePaymentAmount(int studentId) {
		return 0;
	}

	@Override
	public Student getStudentDetails(int studentId) {
		return null;
	}

	@Override
	public Course getCourseDetails(int studentId, int courseId) {
		return null;
	}

	@Override
	public Subject getSubjectDetails(int studentId, int courseId, int subjectId) {
		return null;
	}

	@Override
	public List<Student> getAllStudentDetails() {
		return null;
	}

	@Override
	public List<Course> getAllCourseDetails() {
		return null;
	}

	@Override
	public List<Subject> getAllSubjecttDetails() {
		return null;
	}

	@Override
	public List<Payment> getAllPaymentDetails() {
		return null;
	}

}
