package com.cg.firstcasestudy.utility;

public class Utility {
public static int student_Id_Counter;
public static int course_Id_Counter;
public static int subject_Id_Counter;

}
